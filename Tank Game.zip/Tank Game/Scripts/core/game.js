// Immediate Invoked Anonymous Function
(function () {
    // Global Game Variables
    var canvas = document.getElementById("canvas");
    var stage;
    var helloLabel;

    assetManifest;
    // Store current scene and state information
    var currentScene;
    var currentScene;
    assetManifest = [
        {id: "backButton", src: "./Assets/ChromeDomeLvl1.png"},
        {id: "backButton", src: "./Assets/ChromeDomeLvl2.png"},
        {id: "backButton", src: "./Assets/ChromeDomeLvl3.png"}
        {id: "backButton", src: "./Assets/TankBlack.png"}
        {id: "backButton", src: "./Assets/TankBlue.png"}

        



    ];

    function Init() {
        console.log("Initialization Start");
        Start();
    }
    function Start() {
        console.log("Starting Application...");
        // Initialize CreateJS
        stage = new createjs.Stage(canvas);
        createjs.Ticker.framerate = 60; // 60 FPS
        createjs.Ticker.on("tick", Update);
        Main();
    }
    function Update() {
        stage.update();

    }
    function Main() {
        console.log("Game Start...");
    }
    window.onload = Init;
})();
//# sourceMappingURL=game.js.map